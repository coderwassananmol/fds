#include<iostream>
using namespace std;
int main() {
    int range = 9;
    int arr[] = {1, 4, 1, 2, 7, 5, 2};
    int rangearr[range];
    int outputarr[8];
    for(int i = 0; i<range; i++) {
        rangearr[i] = 0;
    }
    for(int j = 0; j<7; j++) {
        for(int i = 0; i<range; i++) {
            if(arr[j] == i) {
                ++rangearr[i];
            }
        }
    }
    for(int i = 0; i<range; i++) {
        if(i > 0) {
            rangearr[i] += rangearr[i-1];
        }
    }
    
    for(int i = 0; i<7; i++) {
        for(int j = 0; j<range; j++) {
            if(arr[i] == j) {
                outputarr[rangearr[j]] = arr[i];
                --rangearr[j];
            }
        }
    }

    for(int i = 1; i<8; i++) {
        cout << outputarr[i] << " ";
    }
    return 0;
}